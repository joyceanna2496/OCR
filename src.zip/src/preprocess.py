import argparse
import re
import numpy as np
import sys
import os
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold,StratifiedKFold

# -----------------------------
# 把 FASTA 轉成 label + seq
# -----------------------------
def change_char_label(seq,pn,flag=1):
    bed_dict_pos = {}
    out = open(pn+".txt", 'w')
    for line in open(seq, 'r'):
        if line[0] == ">":
            se = line.strip()
            bed_dict_pos[se] = []
        else:
            bed_dict_pos[se].append(line.strip())
    for keys, val in bed_dict_pos.items():
        bed_dict_pos[keys] = ''.join(val)
        out.write(str(flag) + '\t' + bed_dict_pos[keys] + '\n')
    out.close()


# -----------------------------
# One-hot encode
# -----------------------------
def one_hot(filename, nuc_number=1000):
    mapping = {
        "A": [1,0,0,0],
        "C": [0,1,0,0],
        "G": [0,0,1,0],
        "T": [0,0,0,1],
        "N": [0,0,0,0]
    }

    seqs = []
    labels = []

    with open(filename, 'r') as f:
        for line in f:
            line = line.strip().split()
            labels.append(int(line[0]))
            seqs.append(line[1].upper())

    num = len(seqs)
    data = np.zeros((num, nuc_number, 4), dtype=np.int8)

    for i, seq in enumerate(seqs):
        length = min(len(seq), nuc_number)
        for j in range(length):
            data[i, j] = mapping.get(seq[j], [0,0,0,0])

    return data, np.array(labels), seqs


# -----------------------------
# Local 16 features
# -----------------------------
def local_feature(seq):
    seq = seq.upper()
    L = len(seq)
    seg = L // 4

    features = []

    for k in range(4):
        part = seq[k*seg:(k+1)*seg]
        total = len(part)

        if total == 0:
            features += [0,0,0,0]
            continue

        A = part.count("A") / total
        C = part.count("C") / total
        G = part.count("G") / total
        T = part.count("T") / total

        features += [A, C, G, T]

    return np.array(features, dtype=np.float32)


# -----------------------------
# Main
# -----------------------------
def main():
    parser = argparse.ArgumentParser(description='DNA Sequence Processing')
    parser.add_argument('--out', type=str, default='./', help='Output directory')
    parser.add_argument('--pos', type=str, default='pos.fa', help='Positive samples file')
    parser.add_argument('--neg', type=str, default='neg.fa', help='Negative samples file')
    parser.add_argument('--random', action='store_true', help='enable random processing')
    parser.add_argument('--fold', type=int, default=10, help='number of folds for cross-validation')

    args = parser.parse_args()
    pos = args.pos
    neg = args.neg
    out = args.out
    os.makedirs(out, exist_ok=True)

    # One hot_label files
    change_char_label(pos, pn=out+"pos_1hot", flag=1)
    change_char_label(neg, pn=out+"neg_1hot", flag=0)

    data_pos_1, label_pos_1, seq_pos = one_hot(out+"pos_1hot.txt")
    data_neg_1, label_neg_1, seq_neg = one_hot(out+"neg_1hot.txt")

    os.remove(out+"pos_1hot.txt")
    os.remove(out+"neg_1hot.txt")

    seq = np.concatenate((data_pos_1, data_neg_1), axis=0)
    Y = np.concatenate((label_pos_1, label_neg_1), axis=0)

    seq_raw = np.array(seq_pos + seq_neg)

    # =============== NEW: 計算 local 16 features ===============
    local = np.zeros((len(seq_raw), 16), dtype=np.float32)
    for i, s in enumerate(seq_raw):
        local[i] = local_feature(s)

    # shuffle
    np.random.seed(12345)
    idx = np.arange(seq.shape[0])
    np.random.shuffle(idx)

    seq = seq[idx]
    Y = Y[idx]
    local = local[idx]

    # save
    np.save(out+"data_onehot.npy", seq)
    np.save(out+"label.npy", Y)
    np.save(out+"local.npy", local)

    print("✔ data_onehot.npy saved")
    print("✔ local.npy saved (shape:", local.shape, ")")
    print("✔ label.npy saved")


if __name__ == '__main__':
    main()

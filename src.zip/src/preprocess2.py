import argparse
import numpy as np
import os

# ----------------------------
# FASTA 讀取
# ----------------------------
def read_fasta(path):
    seqs = {}
    name = None
    allseq = []
    with open(path) as f:
        for line in f:
            if line.startswith(">"):
                if name:
                    seqs[name] = "".join(allseq)
                name = line.strip()
                allseq = []
            else:
                allseq.append(line.strip())
        if name:
            seqs[name] = "".join(allseq)
    return seqs


# ----------------------------
# One-hot
# ----------------------------
def nuc_to_onehot(c):
    if c in "Aa": return [1,0,0,0]
    if c in "Cc": return [0,1,0,0]
    if c in "Gg": return [0,0,1,0]
    if c in "Tt": return [0,0,0,1]
    return [0,0,0,0]

def seq_to_matrix(seq):
    arr = np.zeros((len(seq), 4), dtype=int)
    for i, c in enumerate(seq):
        arr[i] = nuc_to_onehot(c)
    return arr


# ----------------------------
# Mode: center
# ----------------------------
def center_crop(seq, L=1000):
    n = len(seq)
    if n >= L:
        start = (n - L) // 2
        return seq[start:start + L]
    return seq + "N" * (L - n)


# ----------------------------
# Mode: first1000 (新加入)
# ----------------------------
def first_1000(seq, L=1000):
    seq = seq.upper()
    if len(seq) >= L:
        return seq[:L]
    return seq + "N" * (L - len(seq))


# ----------------------------
# Mode: window
# ----------------------------
def sliding_windows(seq, window=1000, step=200):
    arr = []
    n = len(seq)
    if n <= window:
        return [center_crop(seq, window)]

    for i in range(0, n - window + 1, step):
        arr.append(seq[i:i + window])
    return arr


# ----------------------------
# Mode: segment
# ----------------------------
def segment_reconstruct(seq, window=1000, segment=10):
    seq = seq.upper()
    L = len(seq)
    seg_len = max(1, L // segment)
    segments = [seq[i:i+seg_len] for i in range(0, L, seg_len)]

    AC_ratio = []
    for seg in segments:
        A = seg.count("A"); C = seg.count("C")
        G = seg.count("G"); T = seg.count("T")
        total = A + C + G + T
        AC_ratio.append((A+C)/total if total > 0 else 0.5)

    AC_ratio = np.array(AC_ratio)
    AC_ratio = AC_ratio / AC_ratio.sum()

    new_seq = ""
    for _ in range(window):
        seg = segments[np.random.choice(len(segments), p=AC_ratio)]
        A = seg.count("A"); C = seg.count("C")
        G = seg.count("G"); T = seg.count("T")
        total = A + C + G + T
        if total == 0:
            base = "N"
        else:
            probs = np.array([A,C,G,T]) / total
            base = np.random.choice(["A","C","G","T"], p=probs)
        new_seq += base

    return new_seq


# ----------------------------
# Mode: smooth
# ----------------------------
def smooth_fast(seq, length=1000):
    seq = seq.upper()

    A = seq.count("A"); C = seq.count("C")
    G = seq.count("G"); T = seq.count("T")
    total = A + C + G + T

    if total == 0:
        return "N"*length

    p = np.array([A, C, G, T], dtype=float)
    p = p / p.sum()

    counts = (p * length).astype(int)
    diff = length - counts.sum()

    if diff != 0:
        counts[np.argmax(p)] += diff  # 修正長度

    blocks = ["A"*counts[0], "C"*counts[1], "G"*counts[2], "T"*counts[3]]
    seq_out = "".join(blocks)

    return seq_out[:length]


# ----------------------------
# 16 維 Local Feature
# ----------------------------
def local_feature(seq):
    L = len(seq)
    seg = L // 4

    features = []
    for i in range(4):
        part = seq[i*seg:(i+1)*seg]
        total = len(part)
        A = part.count("A")/total if total else 0
        C = part.count("C")/total if total else 0
        G = part.count("G")/total if total else 0
        T = part.count("T")/total if total else 0
        features += [A,C,G,T]

    return np.array(features, dtype=np.float32)


# ----------------------------
# 主程式
# ----------------------------
def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--pos", required=True)
    parser.add_argument("--neg", required=True)
    parser.add_argument("--out", required=True)

    parser.add_argument("--mode",
        choices=["center","first1000","window","segment","smooth"],
        default="center"
    )

    parser.add_argument("--window", type=int, default=1000)
    parser.add_argument("--step", type=int, default=200)
    parser.add_argument("--segment", type=int, default=10)
    args = parser.parse_args()

    if not os.path.exists(args.out):
        os.makedirs(args.out)

    print("讀取正樣本:", args.pos)
    pos = read_fasta(args.pos)

    print("讀取負樣本:", args.neg)
    neg = read_fasta(args.neg)

    X = []
    L_feat = []
    Y = []

    print(f"\n=== 使用模式: {args.mode} ===\n")

    # ---------------------------
    # 正樣本
    # ---------------------------
    for name, seq in pos.items():

        if args.mode == "center":
            fixed = center_crop(seq, args.window)

        elif args.mode == "first1000":
            fixed = first_1000(seq, args.window)

        elif args.mode == "window":
            for win in sliding_windows(seq, args.window, args.step):
                X.append(seq_to_matrix(win)); L_feat.append(local_feature(win)); Y.append(1)
            continue

        elif args.mode == "segment":
            fixed = segment_reconstruct(seq, args.window, args.segment)

        elif args.mode == "smooth":
            fixed = smooth_fast(seq, args.window)

        X.append(seq_to_matrix(fixed))
        L_feat.append(local_feature(fixed))
        Y.append(1)

    # ---------------------------
    # 負樣本
    # ---------------------------
    for name, seq in neg.items():

        if args.mode == "center":
            fixed = center_crop(seq, args.window)

        elif args.mode == "first1000":
            fixed = first_1000(seq, args.window)

        elif args.mode == "window":
            for win in sliding_windows(seq, args.window, args.step):
                X.append(seq_to_matrix(win)); L_feat.append(local_feature(win)); Y.append(0)
            continue

        elif args.mode == "segment":
            fixed = segment_reconstruct(seq, args.window, args.segment)

        elif args.mode == "smooth":
            fixed = smooth_fast(seq, args.window)

        X.append(seq_to_matrix(fixed))
        L_feat.append(local_feature(fixed))
        Y.append(0)

    X = np.array(X)
    L_feat = np.array(L_feat)
    Y = np.array(Y)

    print("CNN shape :", X.shape)
    print("Local shape:", L_feat.shape)
    print("Label shape:", Y.shape)

    np.save(os.path.join(args.out, "data_onehot.npy"), X)
    np.save(os.path.join(args.out, "local.npy"), L_feat)
    np.save(os.path.join(args.out, "label.npy"), Y)

    print("\n🎉 完成 Hybrid 預處理！")
    print("✔ data_onehot.npy")
    print("✔ local.npy")
    print("✔ label.npy")


if __name__ == "__main__":
    main()
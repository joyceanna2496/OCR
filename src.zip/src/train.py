import h5py
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import time
import math
import argparse
plt.switch_backend('agg')
from sklearn import metrics
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.multiclass import OneVsRestClassifier
import pandas as pd
from sklearn.metrics import accuracy_score
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras import utils as np_utils
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Dropout, Conv1D, Conv2D, MaxPooling1D, MaxPooling2D, LSTM, \
    BatchNormalization, Activation, Flatten, Embedding, ReLU
from tensorflow.keras.layers import GlobalAveragePooling1D, Input, concatenate, ConvLSTM2D
from sklearn.metrics import accuracy_score
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, TensorBoard
from tensorflow.keras import backend as K
from tensorflow.keras.optimizers import SGD
import os
from tensorflow.keras.metrics import Recall, Precision, AUC, BinaryAccuracy
from tensorflow.keras.models import *
from tensorflow.keras.layers import *
from tensorflow.keras.callbacks import *
from tensorflow.keras.initializers import *
from tensorflow.keras.layers import Layer
from tensorflow.keras.regularizers import l1, l2, l1_l2
from tensorflow.keras.backend import squeeze
from tensorflow.keras.models import load_model
from tensorflow.keras.layers import MaxPooling2D, Convolution1D, Convolution2D
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, precision_score, recall_score, f1_score, \
    cohen_kappa_score, precision_recall_curve, average_precision_score, roc_auc_score
from sklearn.metrics import classification_report, confusion_matrix, precision_score, recall_score, f1_score, \
    cohen_kappa_score, precision_recall_curve, average_precision_score, roc_auc_score
from mode_DeepOCR import mode_DeepOCR
import tensorflow as tf
from sklearn.model_selection import train_test_split
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
import random
from sklearn.model_selection import KFold,StratifiedKFold
import tensorflow as tf

# ✅ 新版 TensorFlow 2.x GPU 記憶體動態增長設定
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"✅ {len(gpus)} GPU(s) detected and memory growth enabled.")
    except RuntimeError as e:
        print(e)
else:
    print("⚠️ No GPU detected. Using CPU instead.")

#session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
#sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
#tf.compat.v1.keras.backend.set_session(sess)

def trainDeepOCR(out, train_seq, train_label, test_seq, test_label, val_split, i):

    train_model = mode_DeepOCR()
    loss = tf.keras.losses.binary_crossentropy

    train_model.compile(
        loss=loss,
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        metrics=['accuracy']
    )

    checkpoint = ModelCheckpoint(
        filepath=out + f'model{i}.keras',
        save_best_only=True,
        verbose=1
    )

    early_stopping = EarlyStopping(
        monitor='val_loss',
        patience=20,
        verbose=1
    )

    hist = train_model.fit(
        train_seq,
        train_label,
        batch_size=32,
        epochs=10,
        verbose=1,
        validation_split=val_split,
        shuffle=True,
        callbacks=[checkpoint, early_stopping]
    )

    model_b = load_model(out + f"model{i}.keras", compile=False)
    model_b.compile(loss=loss, optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), metrics=['accuracy'])

    score = model_b.evaluate(test_seq, test_label, verbose=0)
    acc = score[1]

    pred_rate = model_b.predict(test_seq)
    fpr1, tpr1, thresholds = metrics.roc_curve(test_label, pred_rate)
    auc = metrics.auc(fpr1, tpr1)

    pred = (pred_rate > 0.5).astype(int)

    cm = confusion_matrix(test_label, pred)
    tn, fp, fn, tp = cm.ravel()

    Se = tp / (tp + fn)
    Sp = tn / (tn + fp)

    MCC = ((tp * tn) - (fp * fn)) / np.sqrt(
        (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    )

    f1 = f1_score(test_label, pred)

    return acc, auc, Se, Sp, MCC, f1                   

def main():
  parser = argparse.ArgumentParser(description='Training and evaluation')
  parser.add_argument("--out", required=True, help="path to output dir")
  parser.add_argument("--seq", required=True, help="encoded_sequence")
  parser.add_argument("--label", required=True, help="label of sequence(0/1)")
  parser.add_argument("--val", type=float,help="val_split", required=True)
  parser.add_argument("--random", type=float,help="random_split", required=False)
  parser.add_argument('--fold', type=int, help='cross_validation',required=False)
  args = parser.parse_args()
  out=args.out
  seq=args.seq
  label=args.label
  val=args.val
  random=args.random
  fold=args.fold
  seq = np.load(seq)
  seq_path = args.seq  # e.g. data/sheep/Esophagus/output/data_onehot.npy
  seq_dir  = os.path.dirname(seq_path)
  local = np.load(os.path.join(seq_dir, "local.npy"))
  seq = seq.astype('float32')
  local = local.astype('float32')
  label = np.load(label).reshape(-1, 1)
  if args.random:
    i = "_random"

    train_seq, test_seq, train_label, test_label = train_test_split(
        seq, label, test_size=random, shuffle=True
    )

    acc, auc, Se, Sp, MCC, f1 = trainDeepOCR(
        out,
        train_seq,
        train_label,
        test_seq,
        test_label,
        val,        # ← validation split
        i           # ← index/id
    )

    print("=== Final Evaluation ===")
    print(f"Accuracy  : {acc:.4f}")
    print(f"AUC       : {auc:.4f}")
    print(f"Sensitivity (Se): {Se:.4f}")
    print(f"Specificity (Sp): {Sp:.4f}")
    print(f"MCC       : {MCC:.4f}")
    print(f"F1 Score  : {f1:.4f}")

    # 儲存成 text 檔案
    with open(out + "metrics.txt", "w") as f:
        f.write(f"Accuracy: {acc}\n")
        f.write(f"AUC: {auc}\n")
        f.write(f"Sensitivity: {Se}\n")
        f.write(f"Specificity: {Sp}\n")
        f.write(f"MCC: {MCC}\n")
        f.write(f"F1: {f1}\n")

  elif args.fold:
     avg_acc=0
     avg_auc=0
     avg_se=0
     avg_sp=0
     avg_mcc=0
     avg_f1=0
     skf=StratifiedKFold(n_splits=fold,shuffle=True)
     i=0
     for train_index, test_index in skf.split(X,y):
       i+=1
       train_seq, test_seq = seq[train_index], seq[test_index]
       train_label,test_label = label[train_index], label[test_index]
       acc,auc,Se,Sp,MCC,f1=trainDeepOCR(out, train_seq, train_label, test_seq, test_label,val,i)
       avg_acc+=acc
       avg_auc+=auc
       avg_se+=Se  
       avg_sp+=Sp
       avg_mcc+=MCC
       avg_f1+=f1
     print("Acc:",avg_acc/fold)
     print("F1-score:",avg_f1/fold)
     print("Auc:",avg_auc/fold)
     print("Se:",avg_se/fold)
     print("Sp:",avg_sp/fold)
     print("MCC:",avg_mcc/fold)
  else :
     print("Must choose --random or --fold")
         
if __name__ == '__main__':
  main()
    
  

# model_multi_attention.py
import tensorflow as tf
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model


# -----------------------
# Attention blocks
# -----------------------
def position_attention(x, name_prefix):
    """
    Position-wise attention，用於序列還有位置維度時 (batch, L, filters)。
    對每個位置輸出一個 0~1 分數，再乘回原始特徵。
    """
    attn_scores = Conv1D(
        filters=1,
        kernel_size=1,
        activation='sigmoid',
        padding='same',
        name=f"{name_prefix}_scores"
    )(x)
    return Multiply(name=f"{name_prefix}_output")([x, attn_scores])


def filter_attention(x, dim, name_prefix):
    """
    Filter-wise attention，用於 GlobalAvgPool 之後 (batch, filters)。
    對每個 filter 輸出一個 0~1 分數，再乘回原始特徵。
    """
    attn_weights = Dense(
        dim,
        activation='sigmoid',
        name=f"{name_prefix}_weights"
    )(x)
    return Multiply(name=f"{name_prefix}_output")([x, attn_weights])


# -----------------------
# CNN branch
# -----------------------
def DeepOCR_CNN(seq_input, attention=None):
    """
    Args:
        seq_input : Input tensor, shape (batch, 1000, 4)
        attention : None | "conv1d" | "dw2" | "globalavg"
            - None      : 原始架構，不加 attention
            - "conv1d"  : 第一層 Conv1D 之後（原始解析度 L=1000）
            - "dw2"     : 第二個 DW_block 之後、GlobalAvgPool 之前（低解析度）
            - "globalavg": GlobalAvgPool 之後（filter-wise attention）

    Returns:
        tensor, shape (batch, 100)
    """

    def DW_block(X, filters, kernels, name):
        out = SeparableConv1D(filters, kernels, depth_multiplier=1,
                              padding='same', name=f"{name}_sepconv")(X)
        out = ReLU(name=f"{name}_relu1")(out)
        X_c = Conv1D(filters, 1, padding='same', name=f"{name}_shortcut")(X)
        out = add([X_c, out], name=f"{name}_add")
        out = ReLU(name=f"{name}_relu2")(out)
        out = MaxPooling1D(pool_size=3, strides=3, name=f"{name}_pool")(out)
        out = Dropout(0.5, name=f"{name}_drop")(out)
        return out

    x = Conv1D(filters=300, kernel_size=19, padding="same", name="conv1d_1")(seq_input)
    # shape: (batch, 1000, 300)

    if attention == "conv1d":
        x = position_attention(x, name_prefix="conv1d_attn")

    x = DW_block(x, filters=200, kernels=11, name="dw1")
    x = DW_block(x, filters=100, kernels=9,  name="dw2")
    # shape: (batch, L, 100)

    if attention == "dw2":
        x = position_attention(x, name_prefix="dw2_attn")

    x = GlobalAveragePooling1D(name="gap")(x)
    # shape: (batch, 100)

    if attention == "globalavg":
        x = filter_attention(x, dim=100, name_prefix="globalavg_attn")

    return x


# -----------------------
# Multi-input flexible model
# -----------------------
def build_flexible_model(has_local, local_dim, has_kmer, kmer_dim, attention=None):
    """
    Args:
        has_local  : bool
        local_dim  : int or None
        has_kmer   : bool
        kmer_dim   : int or None
        attention  : None | "conv1d" | "dw2" | "globalavg"
    """

    print(f"Attention position : {attention if attention else 'None (baseline)'}")

    # ---- seq CNN branch ----
    seq_input = Input(shape=(1000, 4), name="seq_input")
    cnn_out = DeepOCR_CNN(seq_input, attention=attention)  # shape: (batch, 100)

    inputs = [seq_input]
    merged_features = [cnn_out]

    # ---- local optional ----
    if has_local:
        local_input = Input(shape=(local_dim,), name="local_input")
        inputs.append(local_input)
        merged_features.append(local_input)

    # ---- kmer optional ----
    if has_kmer:
        kmer_input = Input(shape=(kmer_dim,), name="kmer_input")
        inputs.append(kmer_input)
        merged_features.append(kmer_input)

    # ---- merge all ----
    if len(merged_features) > 1:
        merged = concatenate(merged_features, name="concat_features")
    else:
        merged = merged_features[0]

    dense = Dense(300, activation='relu', name="dense_1")(merged)
    dense = Dropout(0.6, name="dropout_1")(dense)
    output = Dense(1, activation='sigmoid', name="output")(dense)

    return Model(inputs=inputs, outputs=output)
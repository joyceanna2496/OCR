# 增加了attention三個位置的選擇

> 終端輸入training指令時，多了 **--attention**
>-	若沒有輸入 --> 原本的train_multi.py
>-	若輸入 --> 有三種選擇(conv1d, dw2, globalavg)
	
## 位置選項說明:
- conv1d: 放在第一層捲積層之後，dropout之前。 篩選哪些位置的motif訊號值得往後傳
- dw2: dropout之後，GlobalAvgPool之前。 比較抽象的重要性(regulatory logics)
- globalavg: GlobalAvgPool之後，(platten、local、kmer)三者concatenate之前。 看filter的重要性(捲積的filter)

---
ps. 若要直接取代原本的train和model:

1. 兩個檔案名稱皆可直接修改為 `train_multi.py`, `model_multi.py`
2. 進入train code，第八行
` from model_multi_attention import build_flexible_model `

     改成 ` from model_multi import build_flexible_model `